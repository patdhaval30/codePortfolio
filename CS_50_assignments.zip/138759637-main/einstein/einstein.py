#give enter from mass with e=mc^2
mass= int(input("Enter mass in kg "))
energy = mass*pow(300000000,2)
print(energy)