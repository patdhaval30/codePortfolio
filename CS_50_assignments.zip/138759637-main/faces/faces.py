#convert :) to smiling face and :( to frowning face in text entered by user
def main():
    name = input("Enter text containing \":)\" or \":(\": ")
    convert(name)

def convert(name):
    name = name.replace(":)","🙂")
    name = name.replace(":(","🙁")
    print(name)

main()
