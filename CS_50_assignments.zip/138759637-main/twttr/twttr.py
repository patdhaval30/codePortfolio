#implement a program that prompts the user for a str of text and then outputs that same text but with all vowels (A, E, I, O, and U) omitted,
#whether inputted in uppercase or lowercase.

def main():
    text = input("Enter a word: ").strip()
    strippedText = removeVowels(text)
    print(strippedText)

def removeVowels(name):
    temp = name
    for vowel in range(len(name)):
        if name[vowel] in ['a','e','i','o','u','A','E','I','O','U']:
            temp, temp1 = temp.split(sep = name[vowel], maxsplit = 1)
            temp = temp + temp1
    return temp


main()