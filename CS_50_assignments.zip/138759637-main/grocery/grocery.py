#implement a program that prompts the user for items, one per line,
#until the user inputs control-d (which is a common way of ending one’s input to a program).
#Then output the user’s grocery list in all uppercase, sorted alphabetically by item,
#prefixing each line with the number of times the user inputted that item. No need to pluralize the items.
#Treat the user’s input case-insensitively.
def main():
    grocery_list()

def grocery_list():
    groceryList = []
    i=0
    while True:
        try:
            groceryItem = input("").strip().upper()
            groceryList.insert(i,groceryItem)
            #for i in range(len(groceryList)):
             #   print(groceryList[i])
            i +=1
        except EOFError:
            grocertdict = {}
            groceryList.sort()
            print()
            for items in range(len(groceryList)):
                grocertdict.update({groceryList[items] : groceryList.count(groceryList[items])})
            #print(grocertdict)
            for item in grocertdict:
                print(grocertdict[item], item, sep=" ")
            break

main()