#repalce space with periods
name = input("enter a text with space: ").strip().replace(" ","...")
print(name)