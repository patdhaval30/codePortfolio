#implement a program that prompts the user for the name of a variable in camel case
# and outputs the corresponding name in snake case.
# Assume that the user’s input will indeed be in camel case.

def main():
    name = input("camelCase: ").strip()
    snakeCase = camel_to_snake(name)
    print(f"snakeCase: {snakeCase} ")

def camel_to_snake(name1):
    snake = name1
    for i in range(len(name1)):
        if name1[i].isupper() :
            snake1, snake2 = snake.split(sep=name1[i], maxsplit =1)
            snake = snake1+"_"+name1[i].lower()+snake2
    return snake

main()

