#implement a program that prompts the user for a fraction, formatted as X/Y, wherein each of X and Y is an integer,
#and then outputs, as a percentage rounded to the nearest integer, how much fuel is in the tank.
# If, though, 1% or less remains, output E instead to indicate that the tank is essentially empty.
#And if 99% or more remains, output F instead to indicate that the tank is essentially full.

#If, though, X or Y is not an integer, X is greater than Y, or Y is 0, instead prompt the user again.
#(It is not necessary for Y to be 4.) Be sure to catch any exceptions like ValueError or ZeroDivisionError.
import math
def main():

    fuelPercent = get_fuel_percent()
    if fuelPercent >= 0.99:
        print("F")
    elif fuelPercent <= 0.01:
        print("E")
    else:
        print(f"{round(fuelPercent*100)}%")

def get_fuel_percent():
    while True:
        try:
            fraction = input("enter a fraction: ").strip()
            x,y = fraction.split(sep="/")
            fuel = float(int(x)/int(y))
            if fuel > 1:
                continue
            return fuel

        except ValueError:
            pass
        except ZeroDivisionError:
            pass


main()