#converting upper case words to lower case
lowerName = input("Enter text to be changed to all lower case: ").lower()
print(lowerName)