#implement a program that prompts the user for a date, anno Domini, in month-day-year order,
#formatted like 9/8/1636 or September 8, 1636, wherein the month in the latter might be any of the values in the list below:

#Then output that same date in YYYY-MM-DD format.
#If the user’s input is not a valid date in either format, prompt the user again. Assume that every month has no more than 31 days;
# no need to validate whether a month has 28, 29, 30, or 31 days.

def main():
    get_date()

def get_date():
    monthList = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"]
    while True:
        try:
            date = input("Date: ").strip()
            if "/" in date :
                month, day, year = date.split(sep="/")
                if (int(month) > 12) or (int(day) > 31):
                    continue
                else:
                    day = "0"+ day if len(day)==1 else day
                    month = "0"+ month if len(month)==1 else month
                    return print(f"{year}-{month}-{day}")
            else:
                month, day, year = date.split(sep = " ")
                if (month not in monthList) or int(day.removesuffix(",")) > 31 or "," not in day:
                    continue
                else:
                    day = day.removesuffix(",")
                    day = "0"+ day if len(day)==1 else day
                    monthNumber = str(monthList.index(month) +1)
                    monthNumber = "0"+ monthNumber if len(monthNumber)==1 else monthNumber
                    return print(f"{year}-{monthNumber}-{day}")
        except ValueError:
            pass

main()